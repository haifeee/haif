// 游戏状态管理
class GameState {
    constructor() {
        this.currentUser = null;
        this.currentRoom = null;
        this.gameStats = {
            wins: 0,
            draws: 0,
            losses: 0,
            score: 1200
        };
        this.battleHistory = [];
        this.currentRound = 1;
        this.playerCards = {
            player1: null,
            player2: null
        };
        this.opponent = null;
    }

    setUser(username) {
        this.currentUser = username;
        // 模拟从本地存储加载用户数据
        const savedData = localStorage.getItem(`gameData_${username}`);
        if (savedData) {
            const data = JSON.parse(savedData);
            this.gameStats = data.gameStats || this.gameStats;
            this.battleHistory = data.battleHistory || [];
        }
    }

    saveUserData() {
        if (this.currentUser) {
            const data = {
                gameStats: this.gameStats,
                battleHistory: this.battleHistory
            };
            localStorage.setItem(`gameData_${this.currentUser}`, JSON.stringify(data));
        }
    }

    createRoom() {
        this.currentRoom = this.generateRoomCode();
        return this.currentRoom;
    }

    joinRoom(roomCode) {
        this.currentRoom = roomCode;
        return true; // 简化处理，实际应该验证房间是否存在
    }

    generateRoomCode() {
        return Math.random().toString(36).substring(2, 8).toUpperCase();
    }

    resetGame() {
        this.currentRound = 1;
        this.playerCards = { player1: null, player2: null };
        this.battleHistory = [];
        this.gameStats.wins = 0;
        this.gameStats.draws = 0;
        this.gameStats.losses = 0;
    }

    playCard(card) {
        this.playerCards.player1 = card;
        // 模拟对手出牌
        const cards = ['king', 'slave', 'citizen'];
        this.playerCards.player2 = cards[Math.floor(Math.random() * cards.length)];
        
        const result = this.calculateResult(this.playerCards.player1, this.playerCards.player2);
        this.addBattleHistory(result);
        
        return {
            playerCard: this.playerCards.player1,
            opponentCard: this.playerCards.player2,
            result: result
        };
    }

    calculateResult(player1Card, player2Card) {
        if (player1Card === player2Card) {
            this.gameStats.draws++;
            return 'draw';
        }

        const winConditions = {
            'king': 'citizen',
            'slave': 'king',
            'citizen': 'slave'
        };

        if (winConditions[player1Card] === player2Card) {
            this.gameStats.wins++;
            return 'win';
        } else {
            this.gameStats.losses++;
            return 'lose';
        }
    }

    addBattleHistory(result) {
        const historyItem = {
            round: this.currentRound,
            playerCard: this.playerCards.player1,
            opponentCard: this.playerCards.player2,
            result: result,
            timestamp: new Date().getTime()
        };
        this.battleHistory.unshift(historyItem);
        this.currentRound++;
    }

    getGameResult() {
        const totalRounds = this.gameStats.wins + this.gameStats.draws + this.gameStats.losses;
        if (totalRounds >= 3) {
            if (this.gameStats.wins > this.gameStats.losses) {
                this.gameStats.score += 25;
                return {
                    result: 'win',
                    title: '恭喜获胜！',
                    description: `你以${this.gameStats.wins}胜${this.gameStats.draws}平${this.gameStats.losses}负的战绩击败了对手`,
                    scoreChange: '+25'
                };
            } else if (this.gameStats.wins < this.gameStats.losses) {
                this.gameStats.score -= 15;
                return {
                    result: 'lose',
                    title: '很遗憾失败了',
                    description: `你以${this.gameStats.wins}胜${this.gameStats.draws}平${this.gameStats.losses}负的战绩败给了对手`,
                    scoreChange: '-15'
                };
            } else {
                return {
                    result: 'draw',
                    title: '平局！',
                    description: `你以${this.gameStats.wins}胜${this.gameStats.draws}平${this.gameStats.losses}负的战绩与对手打平`,
                    scoreChange: '0'
                };
            }
        }
        return null;
    }
}

// 页面管理器
class PageManager {
    constructor() {
        this.currentPage = 'login-page';
        this.pages = [
            'login-page',
            'home-page', 
            'waiting-page',
            'game-page',
            'result-page',
            'rankings-page'
        ];
    }

    showPage(pageId) {
        // 隐藏所有页面
        this.pages.forEach(page => {
            const element = document.getElementById(page);
            if (element) {
                element.classList.add('hidden');
                element.classList.remove('flex');
            }
        });

        // 显示目标页面
        const targetPage = document.getElementById(pageId);
        if (targetPage) {
            targetPage.classList.remove('hidden');
            targetPage.classList.add('flex');
            this.currentPage = pageId;
        }

        // 隐藏模态框
        const modal = document.getElementById('join-room-modal');
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('hidden');
        }
    }

    hideModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('hidden');
        }
    }
}

// 全局实例
const gameState = new GameState();
const pageManager = new PageManager();

// 卡牌信息
const cardInfo = {
    'king': { name: '国王卡', icon: 'fas fa-crown', color: 'text-yellow-500' },
    'slave': { name: '奴隶卡', icon: 'fas fa-shield-alt', color: 'text-red-500' },
    'citizen': { name: '市民卡', icon: 'fas fa-users', color: 'text-blue-500' }
};

// DOM 加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    initializeEventListeners();
    updateUI();
});

function initializeEventListeners() {
    // 登录功能
    const loginBtn = document.getElementById('login-btn');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    
    loginBtn.addEventListener('click', handleLogin);
    usernameInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') handleLogin();
    });
    passwordInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') handleLogin();
    });

    // 主页功能
    document.getElementById('create-room').addEventListener('click', handleCreateRoom);
    document.getElementById('join-room').addEventListener('click', () => {
        pageManager.showModal('join-room-modal');
    });
    document.getElementById('rankings').addEventListener('click', () => {
        pageManager.showPage('rankings-page');
    });
    document.getElementById('logout-btn').addEventListener('click', handleLogout);

    // 加入房间模态框
    document.getElementById('join-room-confirm').addEventListener('click', handleJoinRoom);
    document.getElementById('join-room-cancel').addEventListener('click', () => {
        pageManager.hideModal('join-room-modal');
    });

    // 等待页面
    document.getElementById('cancel-waiting').addEventListener('click', () => {
        pageManager.showPage('home-page');
    });

    // 排行榜
    document.getElementById('back-to-home').addEventListener('click', () => {
        pageManager.showPage('home-page');
    });

    // 游戏页面 - 卡牌选择
    const cardElements = document.querySelectorAll('[data-card]');
    cardElements.forEach(card => {
        card.addEventListener('click', function() {
            const cardType = this.getAttribute('data-card');
            handleCardSelection(cardType, this);
        });
    });

    // 结果页面
    document.getElementById('play-again').addEventListener('click', handlePlayAgain);
    document.getElementById('back-to-home-from-result').addEventListener('click', () => {
        pageManager.showPage('home-page');
    });
}

function handleLogin() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!username) {
        alert('请输入用户名');
        return;
    }

    if (!password) {
        alert('请输入密码');
        return;
    }

    // 简化登录处理
    gameState.setUser(username);
    updateUI();
    pageManager.showPage('home-page');
}

function handleLogout() {
    gameState.saveUserData();
    gameState.currentUser = null;
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    pageManager.showPage('login-page');
}

function handleCreateRoom() {
    const roomCode = gameState.createRoom();
    document.getElementById('room-code').textContent = `#${roomCode}`;
    gameState.resetGame();
    pageManager.showPage('waiting-page');
    
    // 模拟3秒后有玩家加入
    setTimeout(() => {
        if (pageManager.currentPage === 'waiting-page') {
            startGame();
        }
    }, 3000);
}

function handleJoinRoom() {
    const roomId = document.getElementById('room-id-input').value.trim();
    if (!roomId) {
        alert('请输入房间号');
        return;
    }

    gameState.joinRoom(roomId);
    gameState.resetGame();
    pageManager.hideModal('join-room-modal');
    document.getElementById('room-id-input').value = '';
    
    // 直接开始游戏
    startGame();
}

function startGame() {
    gameState.opponent = '对手' + Math.floor(Math.random() * 1000);
    updateGameUI();
    pageManager.showPage('game-page');
}

function handleCardSelection(cardType, cardElement) {
    // 移除之前的选择
    document.querySelectorAll('[data-card]').forEach(card => {
        card.classList.remove('selected');
    });

    // 标记当前选择
    cardElement.classList.add('selected');
    
    // 显示选择状态
    const statusElement = document.getElementById('card-selection-status');
    const selectedCardElement = document.getElementById('selected-card');
    
    selectedCardElement.textContent = cardInfo[cardType].name;
    statusElement.classList.remove('hidden');

    // 延迟执行游戏逻辑
    setTimeout(() => {
        const battleResult = gameState.playCard(cardType);
        processBattleResult(battleResult);
        
        // 检查游戏是否结束
        const gameResult = gameState.getGameResult();
        if (gameResult) {
            setTimeout(() => {
                showGameResult(gameResult);
            }, 2000);
        } else {
            // 重置选择状态
            setTimeout(() => {
                cardElement.classList.remove('selected');
                statusElement.classList.add('hidden');
                updateGameUI();
            }, 2000);
        }
    }, 1500);
}

function processBattleResult(battleResult) {
    addBattleHistoryItem(battleResult);
    updateGameUI();
}

function addBattleHistoryItem(battleResult) {
    const historyContainer = document.getElementById('battle-history');
    const historyItem = createBattleHistoryElement(battleResult);
    
    // 如果是第一个历史记录，清除"暂无对战历史"
    if (historyContainer.children.length === 1 && 
        historyContainer.children[0].textContent.includes('暂无对战历史')) {
        historyContainer.innerHTML = '';
    }
    
    historyContainer.insertBefore(historyItem, historyContainer.firstChild);
}

function createBattleHistoryElement(battleResult) {
    const div = document.createElement('div');
    div.className = 'flex items-center justify-between bg-gray-50 p-3 rounded-lg slide-in';
    
    const resultText = {
        'win': '胜利',
        'lose': '失败', 
        'draw': '平局'
    };
    
    const resultClass = {
        'win': 'text-green-600',
        'lose': 'text-red-600',
        'draw': 'text-gray-600'
    };

    div.innerHTML = `
        <div class="flex items-center">
            <div class="w-10 h-10 bg-white rounded-lg shadow-sm flex items-center justify-center mr-3">
                <i class="${cardInfo[battleResult.playerCard].icon} ${cardInfo[battleResult.playerCard].color}"></i>
            </div>
            <div>
                <p class="font-medium">${cardInfo[battleResult.playerCard].name}</p>
                <p class="text-xs text-gray-500">${gameState.currentUser}</p>
            </div>
        </div>
        <div class="text-center">
            <p class="text-sm font-bold ${resultClass[battleResult.result]}">${resultText[battleResult.result]}</p>
            <p class="text-xs text-gray-500">vs ${cardInfo[battleResult.opponentCard].name}</p>
        </div>
        <div class="flex items-center">
            <div class="text-right mr-3">
                <p class="font-medium">${cardInfo[battleResult.opponentCard].name}</p>
                <p class="text-xs text-gray-500">${gameState.opponent}</p>
            </div>
            <div class="w-10 h-10 bg-white rounded-lg shadow-sm flex items-center justify-center">
                <i class="${cardInfo[battleResult.opponentCard].icon} ${cardInfo[battleResult.opponentCard].color}"></i>
            </div>
        </div>
    `;
    
    return div;
}

function showGameResult(gameResult) {
    gameState.saveUserData();
    
    // 更新结果页面内容
    const resultIcon = document.getElementById('result-icon');
    const resultTitle = document.getElementById('result-title');
    const resultDescription = document.getElementById('result-description');
    const player1ScoreChange = document.getElementById('player1-score-change');
    const player1NewScore = document.getElementById('player1-new-score');
    const player2ScoreChange = document.getElementById('player2-score-change');
    const player2NewScore = document.getElementById('player2-new-score');
    
    // 设置图标和颜色
    if (gameResult.result === 'win') {
        resultIcon.className = 'w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4';
        resultIcon.innerHTML = '<i class="fas fa-trophy text-4xl text-yellow-500"></i>';
        resultTitle.className = 'text-3xl font-bold text-green-600 mb-2';
        player1ScoreChange.className = 'font-bold text-green-600';
    } else if (gameResult.result === 'lose') {
        resultIcon.className = 'w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4';
        resultIcon.innerHTML = '<i class="fas fa-times-circle text-4xl text-red-500"></i>';
        resultTitle.className = 'text-3xl font-bold text-red-600 mb-2';
        player1ScoreChange.className = 'font-bold text-red-600';
    } else {
        resultIcon.className = 'w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4';
        resultIcon.innerHTML = '<i class="fas fa-handshake text-4xl text-gray-500"></i>';
        resultTitle.className = 'text-3xl font-bold text-gray-600 mb-2';
        player1ScoreChange.className = 'font-bold text-gray-600';
    }
    
    resultTitle.textContent = gameResult.title;
    resultDescription.textContent = gameResult.description;
    player1ScoreChange.textContent = gameResult.scoreChange;
    player1NewScore.textContent = gameState.gameStats.score;
    
    // 对手分数变化（相反）
    const opponentScoreChange = gameResult.result === 'win' ? '-15' : 
                               gameResult.result === 'lose' ? '+25' : '0';
    player2ScoreChange.textContent = opponentScoreChange;
    player2ScoreChange.className = opponentScoreChange.startsWith('+') ? 'font-bold text-green-600' : 
                                  opponentScoreChange.startsWith('-') ? 'font-bold text-red-600' : 
                                  'font-bold text-gray-600';
    player2NewScore.textContent = 1150 + parseInt(opponentScoreChange);

    // 更新玩家姓名
    document.getElementById('result-player1-name').textContent = gameState.currentUser;
    document.getElementById('result-player2-name').textContent = gameState.opponent;
    
    pageManager.showPage('result-page');
}

function handlePlayAgain() {
    gameState.resetGame();
    updateGameUI();
    pageManager.showPage('game-page');
}

function updateUI() {
    if (gameState.currentUser) {
        document.getElementById('current-username').textContent = gameState.currentUser;
        document.getElementById('current-score').textContent = gameState.gameStats.score;
    }
}

function updateGameUI() {
    if (gameState.currentUser) {
        document.getElementById('player1-name').textContent = gameState.currentUser;
        document.getElementById('player1-score').textContent = gameState.gameStats.score;
        document.getElementById('current-round').textContent = gameState.currentRound;
        document.getElementById('wins').textContent = gameState.gameStats.wins;
        document.getElementById('draws').textContent = gameState.gameStats.draws;
        document.getElementById('losses').textContent = gameState.gameStats.losses;
    }
    
    if (gameState.opponent) {
        document.getElementById('player2-name').textContent = gameState.opponent;
    }
}

// 添加一些实用工具函数
function showNotification(message, type = 'info') {
    // 创建通知元素
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
        type === 'success' ? 'bg-green-500 text-white' :
        type === 'error' ? 'bg-red-500 text-white' :
        type === 'warning' ? 'bg-yellow-500 text-white' :
        'bg-blue-500 text-white'
    }`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // 3秒后自动移除
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// 添加键盘快捷键支持
document.addEventListener('keydown', function(e) {
    // ESC 键关闭模态框
    if (e.key === 'Escape') {
        pageManager.hideModal('join-room-modal');
    }
    
    // 在游戏页面时，数字键选择卡牌
    if (pageManager.currentPage === 'game-page') {
        if (e.key === '1') {
            document.querySelector('[data-card="king"]').click();
        } else if (e.key === '2') {
            document.querySelector('[data-card="slave"]').click();
        } else if (e.key === '3') {
            document.querySelector('[data-card="citizen"]').click();
        }
    }
});

// 防止页面刷新时丢失状态
window.addEventListener('beforeunload', function() {
    gameState.saveUserData();
});
